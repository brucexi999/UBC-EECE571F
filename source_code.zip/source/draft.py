import torch

node_features = torch.tensor([[[1, 0], [0, 0], [0, 0], [0, 1]],
                              [[1, 0], [0, 0], [0, 0], [0, 1]]], dtype=torch.float32)  # 4 nodes, each with 2 features
adj_mat = torch.tensor([[[0, 1, 1, 0], [1, 0, 0, 1], [1, 0, 0, 1], [0, 1, 1, 0]],
                        [[0, 1, 1, 0], [1, 0, 0, 1], [1, 0, 0, 1], [0, 1, 1, 0]]])  # 4x4 edges, each with a scalar feature
edge_feature_mat = torch.tensor([[0, 2, 2, 0], [2, 0, 0, 2], [2, 0, 0, 2], [0, 2, 2, 0]])

index = torch.tensor([0, 1])
#print(node_features[:,index])

N = adj_mat.shape[1]
range_tensor = torch.arange(N).unsqueeze(1)
target_indices = torch.tensor([1, 2, 0, 3, 0, 3, 1, 2])
comparison_matrix = target_indices == range_tensor
result_indices = comparison_matrix.nonzero(as_tuple=False)


m = torch.tensor([[0.0265, 0.3978],
                  [0.0265, 0.3978],
                  [0.0000, 0.4622],
                  [0.0000, 0.4819],
                  [0.0000, 0.4622],
                  [0.0000, 0.4819],
                  [0.0000, 0.4339],
                  [0.0000, 0.4339]])

#print(range_tensor)
#print(comparison_matrix)
#print(result_indices)
grouped = result_indices[:, 1].view(-1, 2)
print(grouped)
grouped_message = m[grouped]
print(grouped_message)
aggregated_message = torch.sum(grouped_message, dim=1)
print(aggregated_message)
print(aggregated_message.shape)

index=torch.tensor([[[2, 4],
        [0, 6],
        [1, 7],
        [3, 5]], 
        [[2, 4],
        [0, 6],
        [1, 7],
        [3, 5]]])
message = torch.tensor([[[0.0611, 0.0000],
         [0.0611, 0.0000],
         [0.6014, 0.0000],
         [0.0000, 0.1886],
         [0.6014, 0.0000],
         [0.0000, 0.1886],
         [0.2866, 0.0000],
         [0.2866, 0.0000]],

        [[0.0611, 0.0000],
         [0.0611, 0.0000],
         [0.6014, 0.0000],
         [0.0000, 0.1886],
         [0.6014, 0.0000],
         [0.0000, 0.1886],
         [0.2866, 0.0000],
         [0.2866, 0.0000]]])
batch_index = torch.tensor([0,1])
print(message[batch_index, index])
print(torch.sum(message[batch_index, index], dim=2))